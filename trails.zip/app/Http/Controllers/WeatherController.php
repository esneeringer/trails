<?php

namespace App\Http\Controllers;

use App\Trail;
use App\Http\Controllers\Controller;
use App\Services\TrailService;
use App\Services\WeatherService;
use Illuminate\Http\Request;

class WeatherController extends Controller
{
    
}